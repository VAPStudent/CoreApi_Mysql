﻿using DemoCoreMysqlApi.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;

namespace DemoCoreMysqlApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]  
    [EnableCors("CorsPolicy")]
    public class EmpController : ControllerBase
    {
        private IConfiguration configuration;

        public EmpController(IConfiguration iConfig)
        {
            configuration = iConfig;
        }
        private MySqlConnection GetConnection()
        {
            string _Connstr = configuration.GetValue<string>("AppSettings:myConnString");
            return new MySqlConnection(_Connstr);
        }

        //http://localhost/Demo/api/Emp/GetAllEmployee
        //https://localhost:44330/api/Emp/GetAllEmployee
        [HttpGet]
        [Route("GetAllEmployee")]        
        public List<EmpModel> GetAllEmployee()
        {
            cls_Logger obj = new cls_Logger(configuration);
            obj.LogError("Entering GetAllEmployee()");

            List<EmpModel> objList = new List<EmpModel>();

            try
            {
                using (MySqlConnection conn = GetConnection())
                {
                    conn.Open();
                    obj.LogError("DB Connection Opened");
                    MySqlCommand cmd = new MySqlCommand("GetAllEmp", conn);

                    cmd.CommandType = CommandType.StoredProcedure;

                    using (var dr = cmd.ExecuteReader())
                    {
                        obj.LogError("Data Read...");
                        while (dr.Read())
                        {
                            objList.Add(new EmpModel()
                            {
                                EmpId = Convert.ToInt32(dr["EmpId"]),
                                EmpName = dr["EmpName"].ToString(),
                                DOB = dr["DOB"].ToString(),
                                Mobile = dr["Mobile"].ToString(),
                                Email = dr["Email"].ToString(),
                                Latitude = Convert.ToDecimal(dr["Latitude"].ToString()),
                                Longitude = Convert.ToDecimal(dr["Longitude"].ToString())
                            });
                        }
                        obj.LogError("Data Read Completed.");
                    }
                    return objList;
                }
            }
            catch (Exception ex)
            {
                obj.LogError("Error in GetAllEmployee(): " + ex.Message);
                throw ex;
            }
        }

        //http://localhost/Demo/api/Emp/GetEmployee?EmpId=1001
        //https://localhost:44330/api/Emp/GetEmployee?EmpId=1001
        [HttpGet]
        [Route("GetEmployee")]
        public List<EmpModel> GetEmployee(string EmpId)
        {
            cls_Logger obj = new cls_Logger(configuration);
            obj.LogError("Entering GetEmployee(string EmpId)");

            List<EmpModel> objList = new List<EmpModel>();

            try
            {
                using (MySqlConnection conn = GetConnection())
                {
                    conn.Open();
                    obj.LogError("DB Connection Opened");
                    MySqlCommand cmd = new MySqlCommand("SELECT EmpId, EmpName,  DATE_FORMAT(DOB, '%d-%b-%Y') as DOB, Mobile, Email, Latitude, Longitude  FROM employees where EmpId=" + EmpId, conn);

                    using (var reader = cmd.ExecuteReader())
                    {
                        obj.LogError("Data Read...");

                        while (reader.Read())
                        {
                            objList.Add(new EmpModel()
                            {
                                EmpId = Convert.ToInt32(reader["EmpId"]),
                                EmpName = reader["EmpName"].ToString(),
                                DOB = reader["DOB"].ToString(),
                                Mobile = reader["Mobile"].ToString(),
                                Email = reader["Email"].ToString(),
                                Latitude = Convert.ToDecimal(reader["Latitude"].ToString()),
                                Longitude = Convert.ToDecimal(reader["Longitude"].ToString())
                            });
                        }
                        obj.LogError("Data Read Completed.");
                    }
                }
                return objList;
            }
            catch (Exception ex)
            {
                obj.LogError("Error in GetEmployee(string EmpId): " + ex.Message);
                throw ex;
            }
        }
        //http://localhost/Demo/api/Emp/InsUpdEmployee
        //https://localhost:44330/api/Emp/InsUpdEmployee
        //{	
        //"EmpId": 0,
        //"EmpName": "Cholan",
        //"DOB" : "13-12-1983",
        //"Mobile" : "0123456987",
        //"Email" : "cholan@vapstudent.in",
        //"Latitude" : "13.254555",
        //"Longitude" : "80.654755"
        //}
        [HttpPost]
        [Route("InsUpdEmployee")]
        public void InsUpdEmployee([FromBody] EmpModel objData)
        {
            cls_Logger obj = new cls_Logger(configuration);

            try
            {
                obj.LogError("EmpId: " + objData.EmpId);

                using (MySqlConnection conn = GetConnection())
                {
                    MySqlCommand cmd = new MySqlCommand("EmployeeInsUpd", conn);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("p_EmpId", objData.EmpId);
                    cmd.Parameters.AddWithValue("p_EmpName", objData.EmpName);
                    cmd.Parameters.AddWithValue("p_DOB", Convert.ToDateTime(objData.DOB));
                    cmd.Parameters.AddWithValue("p_Mobile", objData.Mobile);
                    cmd.Parameters.AddWithValue("p_Email", objData.Email);
                    cmd.Parameters.AddWithValue("p_Latitude", objData.Latitude);
                    cmd.Parameters.AddWithValue("p_Longitude", objData.Longitude);

                    obj.LogError("After Param");
                    try
                    {
                        conn.Open();

                        obj.LogError("Connection Opened");

                        object objrefid = (Int32)cmd.ExecuteNonQuery();

                        obj.LogError("After Execution");

                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                obj.LogError("Error in InsUpdEmployee(): " + ex.Message);

                throw ex;
            }
        }

        //http://localhost/Demo/api/Emp/DelEmployee?EmpId=1004
        //https://localhost:44330/api/Emp/DelEmployee?EmpId=1004
        [HttpDelete]
        [Route("DelEmployee")]
        public void DelEmployee(string EmpId)
        {
            cls_Logger obj = new cls_Logger(configuration);
            obj.LogError("Entering DelEmployee(string EmpId)");

            List<EmpModel> objList = new List<EmpModel>();

            try
            {
                using (MySqlConnection conn = GetConnection())
                {
                    conn.Open();
                    obj.LogError("DB Connection Opened");
                    MySqlCommand cmd = new MySqlCommand("Delete from employees where EmpId=" + EmpId, conn);

                    cmd.ExecuteNonQuery();

                    obj.LogError("After ExecuteNonQuery()");
                }
            }
            catch (Exception ex)
            {
                obj.LogError("Error in GetEmployee(string EmpId): " + ex.Message);
                throw ex;
            }
        }
    }
}