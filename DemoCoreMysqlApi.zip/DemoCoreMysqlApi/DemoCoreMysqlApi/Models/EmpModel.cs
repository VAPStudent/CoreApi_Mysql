﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace DemoCoreMysqlApi.Models
{
    public class EmpModel
    {
        [DataMember(Name = "EmpId")]
        public int EmpId { get; set; }

        [DataMember(Name = "EmpName")]
        public string EmpName { get; set; }

        [DataMember(Name = "DOB")]
        public string DOB { get; set; }

        [DataMember(Name = "Mobile")]
        public string Mobile { get; set; }

        [DataMember(Name = "Email")]
        public string Email { get; set; }

        [DataMember(Name = "Latitude")]
        public decimal Latitude { get; set; }

        [DataMember(Name = "Longitude")]
        public decimal Longitude { get; set; }
    }
}
